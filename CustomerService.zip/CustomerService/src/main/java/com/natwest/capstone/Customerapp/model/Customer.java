package com.natwest.capstone.Customerapp.model;

import org.apache.commons.codec.binary.Hex;

import javax.persistence.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@Entity
@Table(name="CustomerData", uniqueConstraints = {@UniqueConstraint(columnNames = {"email","mobile"})})
public class Customer {

    @Id
    @Column
    private String id;
    private String name;
    private String email;
    private String address;
    private String password;
    private String mobile;
    private String dob;
    private String idproof;
    private String idproofType;
    private String securityQuestion;
    private String securityAnswer;
    private String CustomerAddedDate;
    private String Status ;
    private String RoundUpAccount;



    public Customer(String name, String email, String address, String password, String mobile, String dob, String idproof, String idproofType, String securityQuestion, String securityAnswer) {
        this.name = name;
        this.email = email;
        this.address = address;
        this.password = ShaConverter(password);
        this.mobile = mobile;
        this.dob = dob;
        this.idproof = idproof;
        this.idproofType = idproofType;
        this.securityQuestion = securityQuestion;
        this.securityAnswer = securityAnswer;
        this.Status="Applied";
    }
    public String ShaConverter(String password){
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());

            // Convert byte array to hexadecimal string using Apache Commons Codec
            String hexString = Hex.encodeHexString(hash);

            // Print the SHA-256 hash
            return hexString;
        }catch (NoSuchAlgorithmException e){
            return password;
        }
    }
    public Customer() {
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
       this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = ShaConverter(password);
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getIdproof() {
        return idproof;
    }

    public void setIdproof(String idproof) {
        this.idproof = idproof;
    }

    public String getIdproofType() {
        return idproofType;
    }

    public void setIdproofType(String idproofType) {
        this.idproofType = idproofType;
    }

    public String getSecurityQuestion() {
        return securityQuestion;
    }

    public void setSecurityQuestion(String securityQuestion) {
        this.securityQuestion = securityQuestion;
    }

    public String getSecurityAnswer() {
        return securityAnswer;
    }

    public void setSecurityAnswer(String securityAnswer) {
        this.securityAnswer = securityAnswer;
    }
    public boolean verifyPassword(String password){
        return this.password.equals(password);
    }

    public String getCustomerAddedDate() {
        return CustomerAddedDate;
    }

    public void setCustomerAddedDate(String customerAddedDate) {
        CustomerAddedDate = customerAddedDate;
    }

    public String getRoundUpAccount() {
        return RoundUpAccount;
    }

    public void setRoundUpAccount(String roundUpAccount) {
        RoundUpAccount = roundUpAccount;
    }
}
