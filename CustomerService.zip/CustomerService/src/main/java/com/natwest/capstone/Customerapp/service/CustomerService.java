package com.natwest.capstone.Customerapp.service;

import com.natwest.capstone.Customerapp.exception.CustomerAlreadyExistsException;
import com.natwest.capstone.Customerapp.exception.CustomerNotFoundException;
import com.natwest.capstone.Customerapp.model.Customer;
import com.natwest.capstone.Customerapp.model.CustomerDto;

import java.util.List;

public interface CustomerService {

    Customer registerCustomer(Customer customer) throws CustomerAlreadyExistsException;
    boolean deleteCustomer(String id) throws CustomerNotFoundException;
    Customer getCustomerById(String id) throws CustomerNotFoundException;
    Customer getCustomerByEmail(String Email) throws CustomerNotFoundException;
    CustomerDto getCustomerDtoById(String id) throws CustomerNotFoundException;
    CustomerDto getCustomerDtoByEmail(String id) throws CustomerNotFoundException;
    boolean validate(Customer customer);

    String getNextId();

    List<Customer> getAllCustomers();

    boolean updatePassword(String id, String password) throws CustomerNotFoundException;
    boolean updatePasswordByEmail(String email, String password) throws CustomerNotFoundException;
    boolean updateRoundUpAccount(String id,String password) throws CustomerNotFoundException;
    boolean updateAddress(String id,String address) throws CustomerNotFoundException;
    boolean updateMobile(String id,String mobile) throws CustomerNotFoundException;
    boolean updateStatus(String id,String status) throws CustomerNotFoundException;
    boolean emailUsed(String email);
    String getRoundupAccountById(String id) throws CustomerNotFoundException;
    String getSecurityQuestionByEmail(String Email) throws CustomerNotFoundException;
    boolean verifySecurityAnswerByEmail(String Email,String answer) throws CustomerNotFoundException;
}
