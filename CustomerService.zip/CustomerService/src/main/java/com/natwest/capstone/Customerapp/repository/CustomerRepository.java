package com.natwest.capstone.Customerapp.repository;

import com.natwest.capstone.Customerapp.model.Customer;
import com.natwest.capstone.Customerapp.model.CustomerDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CustomerRepository extends JpaRepository<Customer,String> {

    Optional<Customer> findFirstByOrderByIdDesc();
    Optional<Customer> findByEmail(String email);

    Optional<CustomerDto> findCustomerDtoById(String id);

}
