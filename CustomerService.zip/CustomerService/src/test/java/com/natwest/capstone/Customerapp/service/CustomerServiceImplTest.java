package com.natwest.capstone.Customerapp.service;

import com.natwest.capstone.Customerapp.exception.CustomerAlreadyExistsException;
import com.natwest.capstone.Customerapp.exception.CustomerNotFoundException;
import com.natwest.capstone.Customerapp.model.Customer;
import com.natwest.capstone.Customerapp.model.CustomerDto;
import com.natwest.capstone.Customerapp.repository.CustomerRepository;
import org.apache.commons.beanutils.BeanUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;



public class CustomerServiceImplTest {
    Customer customer = new Customer();
    CustomerDto customerDto = new CustomerDto();
    private List<Customer> customerList;
    @Mock
    private CustomerRepository customerRepository;

    @InjectMocks
    private CustomerServiceImpl customerService;
    @BeforeEach
    public void init() throws InvocationTargetException, IllegalAccessException {
        MockitoAnnotations.openMocks(this);
        customer = new Customer();
        customer.setId("1050001");
        customer.setName("Test");
        customer.setEmail("Test@example.com");
        customer.setMobile("1234567890");
        customer.setAddress("Test Address");
        customer.setCustomerAddedDate("01/01/2023");
        customer.setRoundUpAccount("88410100025");
        customer.setIdproofType("Aadhar");
        customer.setStatus("Active");
        customer.setIdproof("212457896541");
        customer.setDob("01/01/2001");
        customer.setPassword("abc");
        customerDto = new CustomerDto();
        BeanUtils.copyProperties(customerDto, customer);
        customerList = List.of(customer);
    }


    @Test
    public void testRegisterCustomer() throws CustomerAlreadyExistsException {
        Customer customer = new Customer();
        customer.setEmail("test@example.com");
        when(customerRepository.existsById(any())).thenReturn(false);
        when(customerRepository.save(any(Customer.class))).thenReturn(customer);

        Customer savedCustomer = customerService.registerCustomer(customer);

        assertEquals("test@example.com", savedCustomer.getEmail());
        verify(customerRepository, times(1)).save(customer);
    }


    @Test
    public void testGetCustomerById() throws CustomerNotFoundException {
        Customer customer = new Customer();
        customer.setId("1");
        when(customerRepository.findById("1")).thenReturn(Optional.of(customer));

        Customer foundCustomer = customerService.getCustomerById("1");

        assertEquals("1", foundCustomer.getId());
        verify(customerRepository, times(1)).findById("1");
    }
    @Test
    public void testGetCustomerByEmail() throws CustomerNotFoundException {
        Customer customer = new Customer();
        customer.setEmail("test@example.com");
        when(customerRepository.findByEmail("test@example.com")).thenReturn(Optional.of(customer));

        Customer foundCustomer = customerService.getCustomerByEmail("test@example.com");

        assertEquals("test@example.com", foundCustomer.getEmail());
        verify(customerRepository, times(1)).findByEmail("test@example.com");
    }

    @Test
    public void testGetCustomerDtoById() throws CustomerNotFoundException {
        Customer customer = new Customer();
        customer.setId("1");
        when(customerRepository.findById("1")).thenReturn(Optional.of(customer));

        CustomerDto dto = customerService.getCustomerDtoById("1");

        assertEquals("1", dto.getId());
        verify(customerRepository, times(1)).findById("1");
    }

    @Test
    public void testGetCustomerDtoByEmail() throws CustomerNotFoundException {
        Customer customer = new Customer();
        customer.setEmail("test@example.com");
        when(customerRepository.findByEmail("test@example.com")).thenReturn(Optional.of(customer));

        CustomerDto dto = customerService.getCustomerDtoByEmail("test@example.com");

        assertEquals("test@example.com", dto.getEmail());
        verify(customerRepository, times(1)).findByEmail("test@example.com");
    }

    @Test
    public void testValidate() {
        Customer customer = new Customer();
        customer.setEmail("test@example.com");
        customer.setPassword("password123");
        when(customerRepository.findByEmail("test@example.com")).thenReturn(Optional.of(customer));

        boolean isValid = customerService.validate(customer);

        assertTrue(isValid);
        verify(customerRepository, times(1)).findByEmail("test@example.com");
    }
    @Test
    public void testGetNextIdWhenCustomersExist() {
        Customer customer = new Customer();
        customer.setId("1050005");
        when(customerRepository.findFirstByOrderByIdDesc()).thenReturn(Optional.of(customer));

        String nextId = customerService.getNextId();

        assertEquals("1050006", nextId);
        verify(customerRepository, times(1)).findFirstByOrderByIdDesc();
    }

    @Test
    public void testGetNextIdWhenNoCustomersExist() {
        when(customerRepository.findFirstByOrderByIdDesc()).thenReturn(Optional.empty());

        String nextId = customerService.getNextId();

        assertEquals("1050001", nextId);
        verify(customerRepository, times(1)).findFirstByOrderByIdDesc();
    }

    @Test
    public void testUpdatePassword() throws CustomerNotFoundException {
        Customer customer = new Customer();
        customer.setId("1");
        customer.setPassword("oldPassword");
        when(customerRepository.findById("1")).thenReturn(Optional.of(customer));

        assertTrue(customerService.updatePassword("1", "newPassword"));
        assertEquals(customer.getPassword(), customer.getPassword());
        verify(customerRepository, times(1)).save(customer);
    }

    @Test
    public void testUpdateRoundUpAccount() throws CustomerNotFoundException {
        Customer customer = new Customer();
        customer.setId("1");
        when(customerRepository.findById("1")).thenReturn(Optional.of(customer));

        assertTrue(customerService.updateRoundUpAccount("1", "newAccount"));
        assertEquals("newAccount", customer.getRoundUpAccount());
        verify(customerRepository, times(1)).save(customer);
    }

    @Test
    public void testUpdateAddress() throws CustomerNotFoundException {
        Customer customer = new Customer();
        customer.setId("1");
        when(customerRepository.findById("1")).thenReturn(Optional.of(customer));

        assertTrue(customerService.updateAddress("1", "newAddress"));
        assertEquals("newAddress", customer.getAddress());
        verify(customerRepository, times(1)).save(customer);
    }

    @Test
    public void testUpdateMobile() throws CustomerNotFoundException {
        Customer customer = new Customer();
        customer.setId("1");
        when(customerRepository.findById("1")).thenReturn(Optional.of(customer));

        assertTrue(customerService.updateMobile("1", "newMobile"));
        assertEquals("newMobile", customer.getMobile());
        verify(customerRepository, times(1)).save(customer);
    }

    @Test
    public void testUpdateStatus() throws CustomerNotFoundException {
        Customer customer = new Customer();
        customer.setId("1");
        when(customerRepository.findById("1")).thenReturn(Optional.of(customer));

        assertTrue(customerService.updateStatus("1", "Active"));
        assertEquals("Active", customer.getStatus());
        verify(customerRepository, times(1)).save(customer);
    }

    @Test
    public void testEmailUsed() {
        when(customerRepository.findByEmail("test@example.com")).thenReturn(Optional.of(new Customer()));

        assertTrue(customerService.emailUsed("test@example.com"));
        verify(customerRepository, times(1)).findByEmail("test@example.com");
    }

    @Test
    public void testGetRoundupAccountById() throws CustomerNotFoundException {
        Customer customer = new Customer();
        customer.setId("1");
        customer.setRoundUpAccount("12345");
        when(customerRepository.findById("1")).thenReturn(Optional.of(customer));

        String account = customerService.getRoundupAccountById("1");

        assertEquals("12345", account);
        verify(customerRepository, times(1)).findById("1");
    }

    @Test
    public void testGetSecurityQuestionByEmail() throws CustomerNotFoundException {
        Customer customer = new Customer();
        customer.setEmail("test@example.com");
        customer.setSecurityQuestion("What's your favorite color?");
        when(customerRepository.findByEmail("test@example.com")).thenReturn(Optional.of(customer));

        String question = customerService.getSecurityQuestionByEmail("test@example.com");

        assertEquals("What's your favorite color?", question);
        verify(customerRepository, times(1)).findByEmail("test@example.com");
    }

    @Test
    public void testVerifySecurityAnswerByEmail() throws CustomerNotFoundException {
        Customer customer = new Customer();
        customer.setEmail("test@example.com");
        customer.setSecurityAnswer("blue");
        when(customerRepository.findByEmail("test@example.com")).thenReturn(Optional.of(customer));

        assertTrue(customerService.verifySecurityAnswerByEmail("test@example.com", "blue"));
        assertFalse(customerService.verifySecurityAnswerByEmail("test@example.com", "red"));
        verify(customerRepository, times(2)).findByEmail("test@example.com");
    }




    // Write similar test cases for other methods...

}

