//package com.natwest.capstone.Customerapp.config;
//
//import io.jsonwebtoken.Claims;
//import io.jsonwebtoken.Jwts;
//
//import javax.servlet.*;
//import javax.servlet.annotation.WebFilter;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import java.io.IOException;
//@WebFilter(urlPatterns = {"/*"})
//public class CustomerFilter extends GenericFilter {
//
//    @Override
//    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
//        HttpServletRequest req = (HttpServletRequest) servletRequest;
//        HttpServletResponse res = (HttpServletResponse) servletResponse;
//        String authToken = req.getHeader("authorization");
//        System.out.println(authToken);
//        String jwtToken = authToken.substring(7);
//        System.out.println(jwtToken);
//
//        Claims claims = Jwts.parser().setSigningKey("secretKey")
//                .parseClaimsJws(jwtToken)
//                .getBody();
//        filterChain.doFilter(req,res);
//    }
//}
