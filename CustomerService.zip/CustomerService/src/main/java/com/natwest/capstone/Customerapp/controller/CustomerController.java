package com.natwest.capstone.Customerapp.controller;

import com.natwest.capstone.Customerapp.exception.CustomerAlreadyExistsException;
import com.natwest.capstone.Customerapp.exception.CustomerNotFoundException;
import com.natwest.capstone.Customerapp.model.Customer;
import com.natwest.capstone.Customerapp.model.CustomerDto;
import com.natwest.capstone.Customerapp.service.CustomerService;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1/customer")
public class CustomerController {

    @Autowired
    private CustomerService service;
    String jwtToken;
    public CustomerController(CustomerService service){
        this.service = service;
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerCustomer(@RequestBody Customer customer){
        try{
            Customer registerCustomer=service.registerCustomer(customer);
            return new ResponseEntity<Customer>(registerCustomer,HttpStatus.CREATED);
        }catch (CustomerAlreadyExistsException e){
            return new ResponseEntity<String>(e.getMessage(), HttpStatus.CONFLICT);
        }
    }
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Customer customer, HttpSession session) throws CustomerNotFoundException {
        try{
        boolean flag=service.validate(customer);
        System.out.println(flag);
        Customer fetchedCustomer=null;
        if(flag){
            session.setAttribute("Email",customer.getEmail());
            System.out.println(session.getAttribute("Email"));
            jwtToken=generateToken(customer.getEmail());
            fetchedCustomer=service.getCustomerByEmail(customer.getEmail());
            session.setAttribute("id",fetchedCustomer.getId());
            Map<String, String> response = new HashMap<>();
            response.put("id", fetchedCustomer.getId());
            response.put("token", (String)jwtToken);
            response.put("status", "failure");
            return  new ResponseEntity<Map>(response,HttpStatus.ACCEPTED);
        }else{
            Map<String, String> response = new HashMap<>();
            response.put("status", "failure");
            return  new ResponseEntity<Map>(new HashMap<>(),HttpStatus.CONFLICT);
        }}catch (Exception e){
            Map<String, String> response = new HashMap<>();
            response.put("Error" ,""+e.getMessage());
            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/all")
    public ResponseEntity<List<Customer>> getAllCustomers(){
        return new ResponseEntity<List<Customer>>(service.getAllCustomers(),HttpStatus.OK);
    }

//    @GetMapping("/test")
//    public String sayHello(HttpSession session){
//        System.out.println(session.getId());
//        System.out.println(session.getMaxInactiveInterval());
//
//        if(session.getAttribute("id")==null){
//            return "Please Login First";
//        }
//        return "This Rest API is Working"+session.getAttribute("id");
//    };

    @GetMapping("/allData/{customerId}")
    public ResponseEntity<?> getCompleteCustomerDataById(@PathVariable String customerId){
        try{
            Customer fetchedCustomer=service.getCustomerById(customerId);
            return new ResponseEntity<Customer>(fetchedCustomer, HttpStatus.ACCEPTED);
        }  catch (CustomerNotFoundException e) {
            Map<String, String> response = new HashMap<>();
            response.put("Error" ,""+e.getMessage());
            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/roundUpAccount/{id}")
    public ResponseEntity<?> getRoundUpAccountById(@PathVariable String id){
        try{
            String roundUpAccount = service.getRoundupAccountById(id);
            Map<String, String> response = new HashMap<>();
            response.put("RoundUp", roundUpAccount);
            return new ResponseEntity<Map>(response,HttpStatus.OK);
        }catch (Exception e){
            Map<String, String> response = new HashMap<>();
            response.put("Error" ,""+e.getMessage());
            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
        }
    }
//    @GetMapping("/roundUpAccount")
//    public ResponseEntity<?> getRoundUpAccount(HttpSession session){
//        if(session.getAttribute("id")==null){
//            return new ResponseEntity<String>("Please Login",HttpStatus.UNAUTHORIZED);
//        }
//        try{
//            String roundUpAccount = service.getRoundupAccountById(session.getAttribute("id").toString());
//            Map<String, String> response = new HashMap<>();
//            response.put("RoundUp", roundUpAccount);
//            return new ResponseEntity<Map>(response,HttpStatus.OK);
//        }catch (Exception e){
//            Map<String, String> response = new HashMap<>();
//            response.put("Error" ,""+e.getMessage());
//            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
//        }
//    }
    @GetMapping("/data/{id}")
    public ResponseEntity<?> getCustomerDataById(@PathVariable String id){
        try{
            CustomerDto fetchedCustomer=service.getCustomerDtoById(id);
            return new ResponseEntity<CustomerDto>(fetchedCustomer, HttpStatus.ACCEPTED);
        }  catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("Error" ,""+e.getMessage());
            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
        }
    }
    @GetMapping("/data")
    public ResponseEntity<?> getCustomerData(HttpSession session){
        if(session.getAttribute("id")==null){
            return new ResponseEntity<String>("Please Login",HttpStatus.UNAUTHORIZED);
        }
        String id= session.getAttribute("id").toString();
        try{
            CustomerDto fetchedCustomer=service.getCustomerDtoById(id);
            return new ResponseEntity<CustomerDto>(fetchedCustomer, HttpStatus.ACCEPTED);
        }  catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("Error" ,""+e.getMessage());
            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
        }
    }


    @GetMapping("/check/{email}")
    public ResponseEntity<Map> isEmailRegistered(@PathVariable String email){
        Map<String, String> response = new HashMap<>();
        response.put("Status" ,""+service.emailUsed(email));
        return new ResponseEntity<Map>(response,HttpStatus.OK);
    }

    @PutMapping("/updatePassword")
    public ResponseEntity<?> updatePassword(@RequestBody String password,HttpSession session){
        if(session.getAttribute("id")==null){
            return new ResponseEntity<String>("Please Login",HttpStatus.UNAUTHORIZED);
        }
        String id= session.getAttribute("id").toString();
        try {
            Map<String, String> response = new HashMap<>();
            response.put("Status" ,""+service.updatePassword(id, password));
            return new ResponseEntity<Map>(response,HttpStatus.OK);
        } catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("Error" ,""+e.getMessage());
            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
        }
    }
    @PutMapping("/updatePasswordById/{id}/{password}")
    public ResponseEntity<?> updatePasswordById(@PathVariable String id, @PathVariable String password) {
        try {
            Map<String, String> response = new HashMap<>();
            response.put("Status" ,""+service.updatePassword(id, password));
            return new ResponseEntity<Map>(response,HttpStatus.OK);
        } catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("Error" ,""+e.getMessage());
            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
        }
    }
    @PutMapping("/updatePasswordByEmail/{email}/{password}")
    public ResponseEntity<?> updatePasswordByEmail(@PathVariable String email, @PathVariable String password) {
        try {
            Map<String, String> response = new HashMap<>();
            response.put("Status" ,""+service.updatePasswordByEmail(email, password));
            return new ResponseEntity<Map>(response,HttpStatus.OK);
        } catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("Error" ,""+e.getMessage());
            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
        }
    }
    @PutMapping("/updateRoundUpAccountById/{id}")
    public ResponseEntity<?> updateRoundUpAccountById(@PathVariable String id, @RequestBody String RoundUpAccount) {
        try {
            Map<String, String> response = new HashMap<>();
            response.put("Status" ,""+service.updateRoundUpAccount(id, RoundUpAccount));
            return new ResponseEntity<Map>(response,HttpStatus.OK);
        } catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("Error" ,""+e.getMessage());
            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/updateRoundUpAccount")
    public ResponseEntity<?> updateRoundUpAccount(HttpSession session, @RequestBody String RoundUpAccount) {
        if(session.getAttribute("id")==null){
            return new ResponseEntity<String>("Please Login",HttpStatus.UNAUTHORIZED);
        }
        String id= session.getAttribute("id").toString();
        try {
            Map<String, String> response = new HashMap<>();
            response.put("Status" ,""+service.updateRoundUpAccount(id, RoundUpAccount));
            return new ResponseEntity<Map>(response,HttpStatus.OK);
        } catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("Error" ,""+e.getMessage());
            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
        }
    }
    @PutMapping("/updateAddressById/{id}")
    public ResponseEntity<?> updateAddressById(@PathVariable String id, @RequestBody String Address) {
        try {
            Map<String, String> response = new HashMap<>();
            response.put("Status" ,""+service.updateAddress(id, Address));
            return new ResponseEntity<Map>(response,HttpStatus.OK);
        } catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("Error" ,""+e.getMessage());
            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
        }
    }
//    @PutMapping("/updateAddress")
//    public ResponseEntity<?> updateAddress(HttpSession session, @RequestBody String Address) {
//        if(session.getAttribute("id")==null){
//            return new ResponseEntity<String>("Please Login",HttpStatus.UNAUTHORIZED);
//        }
//        String id= session.getAttribute("id").toString();
//        try {
//            Map<String, String> response = new HashMap<>();
//            response.put("Status" ,""+service.updateAddress(id, Address));
//            return new ResponseEntity<Map>(response,HttpStatus.OK);
//        } catch (Exception e) {
//            Map<String, String> response = new HashMap<>();
//            response.put("Error" ,""+e.getMessage());
//            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
//        }
//    }
    @PutMapping("/updateMobileById/{id}")
    public ResponseEntity<?> updateMobileById(@PathVariable String id, @RequestBody String mobile) {
        try {
            Map<String, String> response = new HashMap<>();
            response.put("Status" ,""+service.updateMobile(id, mobile));
            return new ResponseEntity<Map>(response,HttpStatus.OK);
        } catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("Error" ,""+e.getMessage());
            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
        }
    }
//    @PutMapping("/updateMobile")
//    public ResponseEntity<?> updateMobile(HttpSession session, @RequestBody String mobile) {
//        if(session.getAttribute("id")==null){
//            return new ResponseEntity<String>("Please Login",HttpStatus.UNAUTHORIZED);
//        }
//        String id= session.getAttribute("id").toString();
//        try {
//            Map<String, String> response = new HashMap<>();
//            response.put("Status" ,""+service.updateMobile(id, mobile));
//            return new ResponseEntity<Map>(response,HttpStatus.OK);
//        } catch (Exception e) {
//            Map<String, String> response = new HashMap<>();
//            response.put("Error" ,""+e.getMessage());
//            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
//        }
//    }
    @PutMapping("/updateStatusById/{id}")
    public ResponseEntity<?> updateStatusById(@PathVariable String id, @RequestBody String mobile) {
        try {
            Map<String, String> response = new HashMap<>();
            response.put("Status" ,""+service.updateStatus(id, mobile));
            return new ResponseEntity<Map>(response,HttpStatus.OK);
        } catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("Error" ,""+e.getMessage());
            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
        }
    }
//    @PutMapping("/updateStatus")
//    public ResponseEntity<?> updateStatus(HttpSession session, @RequestBody String mobile) {
//        if(session.getAttribute("id")==null){
//            return new ResponseEntity<String>("Please Login",HttpStatus.UNAUTHORIZED);
//        }
//        String id= session.getAttribute("id").toString();
//        try {
//            Map<String, String> response = new HashMap<>();
//            response.put("Status" ,""+service.updateStatus(id, mobile));
//            return new ResponseEntity<Map>(response,HttpStatus.OK);
//        } catch (Exception e) {
//            Map<String, String> response = new HashMap<>();
//            response.put("Error" ,""+e.getMessage());
//            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
//        }
//    }
    @GetMapping("/getSecurityQuestion/{email}")
    public ResponseEntity<?> getSecurityQuestion(@PathVariable String email) {
        try {
            service.getCustomerByEmail(email);
            Map<String, String> response = new HashMap<>();
            response.put("Question" ,""+service.getSecurityQuestionByEmail(email));
            return new ResponseEntity<Map>(response,HttpStatus.OK);
        } catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("Error" ,""+e.getMessage());
            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
        }
    }
    @GetMapping("/verifySecurityAnswer/{email}/{answer}")
    public ResponseEntity<?> verifySecurityAnswer(@PathVariable String email, @PathVariable String answer) {
        try {
            Map<String, String> response = new HashMap<>();
            response.put("Status" ,""+service.verifySecurityAnswerByEmail(email, answer));
            return new ResponseEntity<Map>(response,HttpStatus.OK);
        } catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("Error" ,""+e.getMessage());
            return new ResponseEntity<Map>(response,HttpStatus.NOT_FOUND);
        }
    }
    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpSession session){
        session.invalidate();
        return new ResponseEntity<String>("Logged Out",HttpStatus.OK);    //returning a string as response.
    }

    public static String generateToken(String id){
        String token = Jwts.builder()
                .setSubject(id)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis()+300000))
                .signWith(SignatureAlgorithm.HS256,"secretKey")
                .compact();
//        System.out.println("Token"+token);
        return token;
    }

}
