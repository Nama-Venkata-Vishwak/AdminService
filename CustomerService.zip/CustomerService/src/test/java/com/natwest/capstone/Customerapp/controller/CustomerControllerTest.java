package com.natwest.capstone.Customerapp.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.capstone.Customerapp.exception.CustomerAlreadyExistsException;
import com.natwest.capstone.Customerapp.exception.CustomerNotFoundException;
import com.natwest.capstone.Customerapp.model.Customer;
import com.natwest.capstone.Customerapp.model.CustomerDto;
import com.natwest.capstone.Customerapp.service.CustomerService;
import org.apache.commons.beanutils.BeanUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@MockitoSettings(strictness = Strictness.LENIENT)
@ExtendWith(MockitoExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class CustomerControllerTest {
    Customer customer = new Customer();
    CustomerDto customerDto = new CustomerDto();
    private List<Customer> customerList;

    MockHttpSession session = new MockHttpSession();

    @MockBean
    private CustomerService service;

    @InjectMocks
    private CustomerController controller;
    @Autowired
    private MockMvc mockMvc;

    @BeforeEach
    public void setUp() throws InvocationTargetException, IllegalAccessException {
        customer = new Customer();
        customer.setId("1050001");
        customer.setName("Test");
        customer.setEmail("Test@example.com");
        customer.setMobile("1234567890");
        customer.setAddress("Test Address");
        customer.setCustomerAddedDate("01/01/2023");
        customer.setRoundUpAccount("88410100025");
        customer.setIdproofType("Aadhar");
        customer.setStatus("Active");
        customer.setIdproof("212457896541");
        customer.setDob("01/01/2001");
        customer.setPassword("abc");
        customerDto = new CustomerDto();
        BeanUtils.copyProperties(customerDto, customer);
        customerList = List.of(customer);
        session = new MockHttpSession();
    }
    @AfterEach
    public void tearDown() {
        customer=null;
        customerDto=null;
        customerList=null;
        session.invalidate();
    }
    @Test
    public void givenRegisterCustomer_whenValidCustomer_thenReturnCustomer() throws Exception {
        when(service.registerCustomer(any())).thenReturn(customer);
//        System.out.println(service.registerAdmin(any()));
        mockMvc.perform(post("/api/v1/customer/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(customer)))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON));
    }

    @Test
    public void givenRegisterCustomer_whenInvalidValidCustomer_thenReturnCustomer() throws Exception {
        when(service.registerCustomer(any())).thenThrow(CustomerAlreadyExistsException.class);
//        System.out.println(service.registerAdmin(any()));
        mockMvc.perform(post("/api/v1/customer/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(customer)))
                .andExpect(status().isConflict());
    }
    @Test
    public void givenLoginCustomer_whenValidCustomer_shouldLogin() throws Exception {
        MockHttpSession session = new MockHttpSession();
        when(service.validate(any())).thenReturn(true);
        when(service.getCustomerByEmail(any())).thenReturn(customer);
        mockMvc.perform(post("/api/v1/customer/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(customer)).session(session))
                .andExpect(status().isAccepted())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON));
    }
    @Test
    public void givenGetAllCustomers() throws Exception {
        when(service.getAllCustomers()).thenReturn(customerList);
        mockMvc.perform(get("/api/v1/customer/all"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .equals(customerList);
    }
    @Test
    public void givenGetMappingById() throws Exception {
        // Mock the service method
        when(service.getCustomerById(any())).thenReturn(customer);
        mockMvc.perform(get("/api/v1/customer/allData/{id}","1050001"))
                .andExpect(status().isAccepted())
                .andExpect(content().contentType("application/json"))
                .equals(customer);
    }

    @Test
    public void givenGetMappingByInvalidId() throws Exception {
        // Mock the service method
        when(service.getCustomerById(any())).thenThrow(CustomerNotFoundException.class);
        mockMvc.perform(get("/api/v1/customer/allData/{id}","1050001"))
                .andExpect(status().isNotFound())
                .andExpect(content().contentType("application/json"));
    }

    @Test
    public void givenGetMapping_ById_ToGet_RoundUPAccount() throws Exception {
       when(service.getRoundupAccountById(any())).thenReturn("98847501114");
       mockMvc.perform(get("/api/v1/customer/roundUpAccount/{id}","1050001"))
               .andExpect(status().isOk())
               .andExpect(content().contentType("application/json"))
               .equals("98847501114");
    }

    @Test
    void getCustomerDataById() throws Exception {
        when(service.getCustomerDtoById(any())).thenReturn(customerDto);
        mockMvc.perform(get("/api/v1/customer/data/{id}","1050001"))
                .andExpect(status().isAccepted())
                .andExpect(content().contentType("application/json"))
                .equals(customerDto);
    }

    @Test
    void getCustomerData() throws Exception {
        MockHttpSession session = new MockHttpSession();
        session.setAttribute("id", "1050001");
        when(service.getCustomerDtoById(any())).thenReturn(customerDto);
        mockMvc.perform(get("/api/v1/customer/data").session(session))
                .andExpect(status().isAccepted())
                .andExpect(content().contentType("application/json"))
                .equals(customerDto);
    }

    @Test
    void isEmailRegistered() throws Exception {
        when(service.emailUsed(any())).thenReturn(true);
        mockMvc.perform(get("/api/v1/customer/check/{email}","test@example.com"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .equals(true);
    }


    @Test
    void updatePasswordById() throws Exception{
        when(service.updatePassword(any(),any())).thenReturn(true);
        mockMvc.perform(put("/api/v1/customer/updatePasswordById/{id}/{password}","id","pass"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .equals(true);
    }

    @Test
    void updatePasswordByEmail() throws Exception{
        when(service.updatePasswordByEmail(any(),any())).thenReturn(true);
        mockMvc.perform(put("/api/v1/customer/updatePasswordByEmail/{email}/{password}","email","pass"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .equals(true);
    }

    @Test
    void updateRoundUpAccountById() throws Exception{
        when(service.updateRoundUpAccount(any(),any())).thenReturn(true);
        mockMvc.perform(put("/api/v1/customer/updateRoundUpAccountById/{id}","id").contentType(MediaType.APPLICATION_JSON).content("1050123654"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .equals(true);
    }

    @Test
    void updateRoundUpAccount() throws Exception{
        MockHttpSession session = new MockHttpSession();
        session.setAttribute("id", "1050001");
        when(service.updateRoundUpAccount(any(),any())).thenReturn(true);
        mockMvc.perform(put("/api/v1/customer/updateRoundUpAccount","id").session(session).contentType(MediaType.APPLICATION_JSON).content("1050123654"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .equals(true);
    }


    @Test
    void updateAddressById() throws Exception{
        when(service.updateAddress(any(),any())).thenReturn(true);
        mockMvc.perform(put("/api/v1/customer/updateAddressById/{id}","id").contentType(MediaType.APPLICATION_JSON).content("test"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .equals(true);
    }

//    @Test
//    void updateAddress() throws Exception{
//        MockHttpSession session = new MockHttpSession();
//        session.setAttribute("id", "1160001");
//    }

    @Test
    void updateMobileById() throws Exception{
        when(service.updateAddress(any(),any())).thenReturn(true);
        mockMvc.perform(put("/api/v1/customer/updateMobileById/{id}","id").contentType(MediaType.APPLICATION_JSON).content("test"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .equals(true);
    }

//    @Test
//    void updateMobile() throws Exception{
//        MockHttpSession session = new MockHttpSession();
//        session.setAttribute("id", "1160001");
//    }

    @Test
    void updateStatusById() throws Exception{
        when(service.updateStatus(any(),any())).thenReturn(true);
        mockMvc.perform(put("/api/v1/customer/updateStatusById/{id}","id").contentType(MediaType.APPLICATION_JSON).content("test"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .equals(true);
    }

//    @Test
//    void updateStatus() throws Exception{
//        MockHttpSession session = new MockHttpSession();
//        session.setAttribute("id", "1160001");
//    }

    @Test
    void getSecurityQuestion() throws Exception{
        when(service.getSecurityQuestionByEmail(any())).thenReturn("abc");
        mockMvc.perform(get("/api/v1/customer/getSecurityQuestion/{email}","test@example.com"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .equals("abc");
    }

    @Test
    void verifySecurityAnswer() throws Exception{
        when(service.verifySecurityAnswerByEmail(any(),any())).thenReturn(true);
        mockMvc.perform(get("/api/v1/customer/verifySecurityAnswer/{email}/{answer}","test@example.com","ans"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .equals(true);
    }

    @Test
    void logout() throws Exception{
        MockHttpSession mockHttpSession = new MockHttpSession();
        mockHttpSession.setAttribute("id", "1160001");
        mockMvc.perform(post("/api/v1/customer/logout").session(mockHttpSession))
                .andExpect(status().isOk())
                .andExpect(content().contentType("text/plain;charset=ISO-8859-1"))
                .equals("Logged Out");
    }

    @Test
    void givenStringTo_GenerateToken_Should_returnString() throws Exception {
        String token = CustomerController.generateToken("XXXXXXXXXXXXXXXXXXX");
        assert token != null;
    }

    private String asJsonString(Object object) throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(object);
    }
}
