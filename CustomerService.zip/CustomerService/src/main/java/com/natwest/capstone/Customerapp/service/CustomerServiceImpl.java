package com.natwest.capstone.Customerapp.service;

import com.natwest.capstone.Customerapp.exception.CustomerAlreadyExistsException;
import com.natwest.capstone.Customerapp.exception.CustomerNotFoundException;
import com.natwest.capstone.Customerapp.model.Customer;
import com.natwest.capstone.Customerapp.model.CustomerDto;
import com.natwest.capstone.Customerapp.repository.CustomerRepository;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class CustomerServiceImpl implements CustomerService{

    @Autowired
    private CustomerRepository repository;

    public CustomerServiceImpl(CustomerRepository repository){
        this.repository=repository;
    }

    @Override
    public Customer registerCustomer(Customer customer) throws CustomerAlreadyExistsException {
        Customer savedCustomer=null;
        customer.setId(getNextId());
        if(repository.existsById(customer.getId())){
            throw new CustomerAlreadyExistsException("Customer ID "+customer.getId()+" already exists");
        }else{
            System.out.println(getNextId());
            customer.setCustomerAddedDate(new SimpleDateFormat("dd/MM/yyyy").format(new Date()));
            customer.setStatus("Pending");
            savedCustomer=repository.save(customer);
            if(savedCustomer==null){
                throw new CustomerAlreadyExistsException("Customer ID "+customer.getId()+" already exists");
            }
        }
        return savedCustomer;
    }



    @Override
    public boolean deleteCustomer(String id) throws CustomerNotFoundException {
        return false;
    }

    @Override
    public Customer getCustomerById(String id) throws CustomerNotFoundException {
        Customer fetchedCustomer=repository.findById(id).get();
        if(fetchedCustomer ==null){
            throw new CustomerNotFoundException("User doesn't exist");
        }
        return fetchedCustomer;
    }

    @Override
    public Customer getCustomerByEmail(String Email) throws CustomerNotFoundException {
        Customer fetchedCustomer=repository.findByEmail(Email).get();
        if(fetchedCustomer ==null){
            throw new CustomerNotFoundException("User doesn't exist");
        }
        return fetchedCustomer;
    }

    @Override
    public CustomerDto getCustomerDtoById(String id) throws CustomerNotFoundException {
        CustomerDto dto =new CustomerDto();
        Customer data = getCustomerById(id);
        try{
        BeanUtils.copyProperties(dto, data);
        }catch (Exception e){
            System.out.println("Error***********************");
        }
        return dto;
    }

    @Override
    public CustomerDto getCustomerDtoByEmail(String Email) throws CustomerNotFoundException {

        Customer fetchedCustomer=repository.findByEmail(Email).get();
        if(fetchedCustomer ==null){
            throw new CustomerNotFoundException("User doesn't exist");
        }
        CustomerDto dto =new CustomerDto();
        try{
            BeanUtils.copyProperties(dto, fetchedCustomer);
        }catch (Exception e){
            System.out.println("Error***********************");
        }
        return dto;
    }

    @Override
    public boolean validate(Customer customer) {
        Optional<Customer> optCustomer=repository.findByEmail(customer.getEmail());
        if(optCustomer.isPresent()){
//            System.out.println("opt,");
//            System.out.println(customer.getPassword()+" "+optCustomer.get().getPassword());
            if(customer.verifyPassword(optCustomer.get().getPassword())){
                return true;
            }
            else
                return false;
        }
        return false;
    }

    @Override
    public String getNextId() {
        Optional<Customer> customer = repository.findFirstByOrderByIdDesc();
        if (customer.isPresent()) {
            return ""+(Integer.parseInt(customer.get().getId())+1);
        } else {
            return "1050001"; // Default value if no customers
        }

    }

    @Override
    public List<Customer> getAllCustomers() {
        return (List<Customer>) repository.findAll();
    }

    @Override
    public boolean updatePassword(String id, String password) throws CustomerNotFoundException {
        Customer cust = getCustomerById(id);
        cust.setPassword(password);
        repository.save(cust);
        Customer cust2=getCustomerById(id);
        if(cust2.getPassword().equals(cust2.ShaConverter(password))){
            return true;
        }
        return false;
    }
    @Override
    public boolean updatePasswordByEmail(String email, String password) throws CustomerNotFoundException {
        Customer cust = getCustomerByEmail(email);
        cust.setPassword(password);
        repository.save(cust);
        Customer cust2=getCustomerById(cust.getId());
        if(cust2.getPassword().equals(cust2.ShaConverter(password))){
            return true;
        }
        return false;
    }

    @Override
    public boolean updateRoundUpAccount(String id, String account) throws CustomerNotFoundException {
        Customer cust = getCustomerById(id);
        cust.setRoundUpAccount(account);
        repository.save(cust);
        Customer cust2=getCustomerById(id);
        if(cust2.getRoundUpAccount()==account){
            return true;
        }
        return false;
    }

    @Override
    public boolean updateAddress(String id, String address) throws CustomerNotFoundException {
        Customer cust = getCustomerById(id);
        cust.setAddress(address);
        repository.save(cust);
        Customer cust2=getCustomerById(id);
        if(cust2.getAddress()==address){
            return true;
        }
        return false;
    }

    @Override
    public boolean updateMobile(String id, String mobile) throws CustomerNotFoundException {
        Customer cust = getCustomerById(id);
        cust.setMobile(mobile);
        repository.save(cust);
        Customer cust2=getCustomerById(id);
        if(cust2.getMobile()==mobile){
            return true;
        }
        return false;
    }

    @Override
    public boolean updateStatus(String id, String status) throws CustomerNotFoundException {
        Customer cust = getCustomerById(id);
        cust.setStatus(status);
        repository.save(cust);
        Customer cust2=getCustomerById(id);
        if(cust2.getStatus()==status){
            return true;
        }
        return false;
    }

    @Override
    public boolean emailUsed(String email) {
        return repository.findByEmail(email).isPresent();
    }

    @Override
    public String getRoundupAccountById(String id) throws CustomerNotFoundException {
        Customer fetchedCustomer=repository.findById(id).get();
        if(fetchedCustomer ==null){
            throw new CustomerNotFoundException("User doesn't exist");
        }
        return fetchedCustomer.getRoundUpAccount();
    }

    @Override
    public String getSecurityQuestionByEmail(String Email) throws CustomerNotFoundException {
        Customer fetchedCustomer=repository.findByEmail(Email).get();
        if(fetchedCustomer ==null){
            throw new CustomerNotFoundException("User doesn't exist");
        }
        return fetchedCustomer.getSecurityQuestion();
    }

    @Override
    public boolean verifySecurityAnswerByEmail(String Email, String answer) throws CustomerNotFoundException {
        Customer fetchedCustomer=repository.findByEmail(Email).get();
        if(fetchedCustomer ==null){
            throw new CustomerNotFoundException("User doesn't exist");
        }
        return fetchedCustomer.getSecurityAnswer().trim().equalsIgnoreCase(answer.trim());

    }


}
